<?php
// index.php
header('Location: view/landingPage.html');
exit();
