<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retake Quiz</title>
</head>
<body>
    <h1>You Need to Retake the Quiz</h1>
    <p>Unfortunately, you didn't pass. Please try again.</p>
</body>
</html>
